<?php
 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';
 

 
if (isset($_POST['send'])) {
    //$name = htmlentities($_POST['name']);
    $email = htmlentities($_POST['email']);
    //$subject = htmlentities($_POST['subject']);
    //$message = htmlentities($_POST['message']);
 
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'pruebag389@gmail.com';
    $mail->Password = 'obrcjccomfeycftn';
    $mail->Port = 465;
    $mail->SMTPSecure = 'ssl';
    $mail->isHTML(true);
    $mail->setFrom($email);
    $mail->addAddress('diegobautista3007@gmail.com');
    $mail->Subject = ("Quieres mas informacion del modo de ingreso");
    $mail->Body = "Bienvenido";
    $mail->send();
 
    header("Location: ./inicio.php?=email_sent!");
}
?>

<!DOCTYPE html>

<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/inicio.css">
  <title>Formulario de Registro Uniempresarial</title>
</head>
<body>
  <div id="container">
    <div id="left-side">
      <img class="logo" src="../img/logo.png" alt="Logo">
      <h1>BIENVENIDOS AL FORMULARIO DE REGISTRO UNIEMPRESARIAL</h1>
    </div>
    <div id="right-side">
      <h2>¿Qué entidad eres?</h2>
      <div class="button-container">
        <button onclick="window.location.href='formulario.html'">
          <img src="../img/estudiante.png" alt="formulario Logo">
          <span>Estudiante</span>
        </button>
        <button onclick="window.location.href='invitado.html'">
          <img src="../img/invitado.png" alt="Invitado Logo">
          <span>Invitado</span>
        </button>
        <button onclick="window.location.href='admin.html'">
          <img src="../img/admin.png" alt="Administrador Logo">
          <span>Administrador</span>
        </button>
        <button onclick="window.location.href='equipo.html'">
          <img src="../img/compu.png" alt="equipo Logo">
          <span>Registro de Computo</span>
        </button>
      </div>
      <form method="post">
 
        <div class="letter-head">
            <h2> Quieres mas informacion</h2>
        </div>
        <div class="letter-input">
            <div>
                <input type="email" name="email" placeholder="email">
            </div>
            <button type="submit" name="send" class="red_btn">Enviar</button>
        </div>
        
    </form>
    
    </div>
  </div>
</body>
</html>






